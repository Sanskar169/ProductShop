package test;

public class DBInfo {
	public static final String dbUrl="jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String uName="system";
	public static final String pWord="sanskar";

}
